from network.sock import SocketClient


name = input("Введите ваше имя: ")


sock = SocketClient('192.168.0.106', 8000)
sock.connect()

sock.send(name)
server = sock.get(1024)

print(f"Вы подключились к серверу {server}.")
while True:
      message = sock.get(1024)
      print(f"{server}: {message}")

      message = input("Вы: ")


      
      sock.send(message)

