from network.sock import SocketServer


name = input("Введите ваше имя: ")

server = SocketServer('192.168.0.106', 8000)
server.accept(10)

print("Ожидание клиентов...")

client = server.get(1024)
print(f"{client} подключился к чату!")
server.send(name)

while True:
      message = input("Вы: ")


      server.send(message)
      message = server.get(1024)
      print(f"{client}: {message}")
      

      

